public class Biuro {
    //szymon
    public String imie;
    public String stanowisko;
    public double wyplata;

    public Biuro(String imie, String stanowisko, double wyplata) {

        this.imie = imie;
        this.stanowisko = stanowisko;
        this.wyplata = wyplata;
    }
}
